import React from 'react';

const Slide04 = () => (
  <section>
    <h2>Bulletpoints</h2>
    <br />
    <ol>
      <li>One</li>
      <li>Two</li>
      <li>Three</li>
    </ol>
  </section>
);

export default Slide04;

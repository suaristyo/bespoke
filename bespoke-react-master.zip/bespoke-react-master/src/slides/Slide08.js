import React from 'react';

const Slide08 = ({ deck }) => (
  <section>
    <h2>
      <a href="https://github.com/diegomura/bespoke-react">
        Check out the project!
      </a>
    </h2>
  </section>
);

export default Slide08;
